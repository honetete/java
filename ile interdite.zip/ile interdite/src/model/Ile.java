package model;

/**
 * une Ile est constitué de zones disposées en grille
 */

public class Ile {
	
	/** 
	 * enum sert à représenter les différents états possibles d'une zone
	 */
	
	public enum Etat {
		EMERGE,
		INONDE,
		SUBMERGE;
	};
	
	/**
	 * une zone est définie par son état
	 */
	
	public class Zone {

		/**
		 * représente l'état courant de la zone
		 */
		
		private Etat etat;
		
		/**
		 * etat par défaut d'une zone est défini comme emerge
		 */
		
		public Zone(){
			
			etat = Etat.EMERGE;
		}
		
		/**
		 * @param etat etat de départ de la zone
		 */
		
		public Zone(Etat etat){
			
			this.etat = etat;
		}
		
		/**
		 * 
		 * @return l'état de la zone (méthode getter)
		 */
	
		public Etat getEtat() {
			
			return etat;
		}
	
	}
	
	/**
	 * attribut de l'ile / grille 2D de zone
	 */
	
	private Zone[][] grille;  //array de zones
	
	/**
	 * Construit une grille de dimension largeur*hauteur de zones.
	 * @param hauteur nb de zones en hauteur 
	 * @param largeur nb de zones en largeur
	 * 
	 */
	
	public Ile(int hauteur, int largeur){
		
		assert(hauteur > 0 && largeur > 0); //verification des parametres =! de 0
		
		this.grille = new Zone[largeur][hauteur]; //taille d'un array de zone 
		// this.grille = new Zone(largeur, hauteur); taille d'une zone
		
		//double for pour parcourir la grille et associer une zone par défaut emerge par case
		for(int x = 0; x< grille.length; x++){
			for(int y = 0; y< grille[x].length; y++){
				grille[x][y] = new Zone();
			}
		}
	}
	
	
	public Zone getZone(int x,int y){
		
		assert(x>=0 && y>=0 && x<=grille.length && y<=grille[x].length);
		
		return grille[x][y];
	}

}
